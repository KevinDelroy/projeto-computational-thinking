console.log('BEM VINDO AO JOGO DAS PORTAS!')
console.log('Descubra qual porta é a verdadeira!!!!')
var p = 1 

for (var p = 1; p <= 5; p++)
console.log(`porta ${p}`)

var porta = prompt ('Qual porta gostaria de testar?')

while(porta == 'porta 4'){
  console.log('PORTA VERDADEIRA! DESCUBRA QUAL CHAVE A ABRE!')
  break;
}
if(porta != 'porta 4'){
  console.log('PORTA FALSA!')
}
console.log('===============================================')

var x = 1

for (var x = 1; x <= 5; x++)
console.log(`chave ${x}`)

var chave = prompt ('Qual chave gostaria de testar?')

if(chave == 'chave 3'){
  console.log('CHAVE CERTA!')
} else {
  console.log('CHAVE ERRADA!')
}
console.log('===============================================')
console.log('Você chegou a fase final!')

for (var numero = 1; numero <= 5; numero++)
console.log(`fruta ${numero}`)

var numero = prompt ('Escolha uma fruta entre 1 e 5!')

switch(numero){
  case '1':
  console.log('Banana boa! VOCÊ GANHOU!')
  break;
  case '2':
  console.log('Abacaxi bom! VOCÊ GANHOU!')
  break;
  case '3':
  console.log('Maça envenenada!! VOCÊ PERDEU!')
  break;
  case '4':
  console.log('Manga boa! VOCÊ GANHOU!')
  break;
  case '5':
  console.log('Melancia envenenada!! VOCÊ PERDEU!')
  break;
}
console.log('===============================================')

var x = prompt ('Feedback do criador! Entre 0 e 5 qual nota você daria ao minigame?') 

do{
  console.log(`Nota ${x}! Obrigado!`)
  x++
} while (x >= 5)




